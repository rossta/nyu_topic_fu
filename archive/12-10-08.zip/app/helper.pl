#!/usr/bin/perl -w

require "globals.pl";
use POSIX qw(strftime);

sub page_start {
  print start_html( -title    => "Unix Tools: Final Assignment, Topic Fu", 
          -style     => {-src => "$PUBLIC_DIR/stylesheets/topic_fu.css"},
          -text     => "#666",
        );
}
sub validate_topic {
  warn "validating action: " . param('action');
  if(param('action')) {
    if(param('topic')) {
      ($FLASH = error_on_topic_text(param('topic'))) || return param('topic');
    } else {
      $FLASH = "Error: topic cannot be blank!";
      warn "validation error: topic left blank";
    }
  }
  return "Choose a topic";
}
sub error_on_topic_text {
  foreach (@_) {
    if(/[^A-Za-z0-9]+/) {
      warn "Error: topic contains invalid chars";
      return "Error: topic contains invalid chars"; 
    }
  }
}

sub get_action {
  if(param('action')) {
    return param('action');
  } else {
    return 'home';
  }
}
sub home_dir {
  return "/Users/ross" if $DEBUG;
  return "/home/rk1023";
}

sub html_format {
  $_ = shift @_;
  my %escape = ('&' => '&amp;', '<' => '&lt;', '>' => '&gt;');
  my $replace = join '', keys %escape;
  warn "formatting: $_" if $DEBUG;
  s/([$replace])/$escape{$1}/g;
  s/^\r[\n]?$/<p>/gm;
  s/^---\+ ([^\r\n]*)/<h1>$1<\/h1>/gm;
  s/^---\+\+ ([^\r\n]*)/<h2>$1<\/h2>/gm;
  s/^---\+\+\+ ([^\r\n]*)/<h3>$1<\/h3>/gm;
  s/\*([^\*]*)\*/<b>$1<\/b>/gm;
  s/_([^_]*)_/<i>$1<\/i>/gm;
  s/\!([^\!]*)\!/<img src="$1" \/>/gm;
  $_ = &bulleted_lists($_);
  s/[\r\n]*//gm;
  warn "formatting: $_" if $DEBUG;
  $_ = &link_topics($_);
  return $_;
}
sub bulleted_lists {
  my $html = shift @_;
  $html =~ s/\r\n- ([^\r\n]*)/<li>$1<\/li>/g;
  $html =~ s/(<li>.*<\/li>)[^<]?/<ul>$1<\/ul>/g;
  $html =~ s/\r\n[0-9]+\. ([^\r\n]*)/<li>$1<\/li>/g;
  $html =~ s/([^>])(<li>.*<\/li>)[^<]?/$1<ol>$2<\/ol>/g;
  return $html;
}
sub link_topics {
  my $html = shift @_;
  warn "dir: $SID/$TOPIC_DIR" if $DEBUG;
  @topics = `ls $SID/$TOPIC_DIR`;
  foreach(@topics) {
    chomp($_);
    warn "existing topic: $_" if $DEBUG;
    my $href = &view_path($_);
    $html =~ s/$_/<a href="$href">$_<\/a>/gm;
  }
  warn "html: $html" if $DEBUG;
  return $html;
}
sub view_path {
  my $file = shift @_;
  return "$HOME_URL?action=view&topic=$file";
}

sub file_data {
  $_ = shift @_;
  %file = {};
  my @filename = split(/\//, $_);
  $file{'timestamp'} = pop(@filename);
  $file{'name'} = pop(@filename);
  $file{'href'} = &view_path($file{'name'});
  return %file;
}

sub sorted_topic_list {
  return sort{
    @list_a = split(/\//, $a);
    @list_b = split(/\//, $b);
    my $time_a = pop(@list_a);
    my $time_b = pop(@list_b);
    return $time_b <=> $time_a;
  } @_;
}

sub time_format {
  my $format = shift @_;
  my $time = shift @_;
  return strftime($format, localtime($time));
}

