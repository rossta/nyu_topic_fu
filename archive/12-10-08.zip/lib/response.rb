require 'net/http'
require 'uri'
require 'hpricot'

module Response

  URL = "http://localhost/cgi-bin/topic_fu"
  
  def doc(method = :get, params = {})
    if method == :post
      Hpricot(post_form("#{URL}", params))
    else
      Hpricot(get("#{URL}"))
    end
  end
  
  def response(element)
    (doc(:post, merge_test({}))/element).inner_html
  end
  
  def response_attribute(element, attribute)
    (doc(:post, merge_test({}))/element).first[attribute.to_sym]
  end
  
  def response_post(element, params = {})
    (doc(:post, merge_test(params))/element).inner_html
  end

  def response_post_attribute(element, attribute, params = {})
    (doc(:post, merge_test(params))/element).first[attribute.to_sym]
  end
  
  def preview_response(params, locator = "div.content")
    response_post(locator, params).chomp
  end

  def preview_response_attribute(params, locator, attribute)
    response_post_attribute(locator, attribute, params).chomp
  end

protected
  def merge_test(params)
    params.merge("test_link"=>STUDENT_ID, "test_dir" => "test_topic")
  end

  def parse(url)
    URI.parse(url)
  end
  
  def get(url)
    Net::HTTP.get(parse(url))
  end
  
  def post_form(url, params = {})
    Net::HTTP.post_form(parse(url), params).body
  end
  
end
