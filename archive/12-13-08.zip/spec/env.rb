require File.dirname(__FILE__) + '/../../rspec/spec/spec_helper'
require 'lib/response'
require 'lib/simplestore_helper'

include Response
include SimplestoreHelper